import pandas as pd
import numpy as np
import os

myname = "srijit sen"
lib_path = "D:/MDS related Documents/Deep Learning/Assignment 1/"
os.chdir(lib_path)

training_data=pd.read_csv('qn2_data.csv',names=('Fert','Insect','Corn'))
y=training_data['Corn'].values
x=training_data.drop('Corn', axis=1).values
test_set = np.array([[6,4],[10,5],[14,8]])

from sklearn.linear_model import LinearRegression
# creating an object of LinearRegression class


LR = LinearRegression()
# fitting the training data
reg=LR.fit(x,y)

LR.predict(test_set)

reg.coef_
reg.intercept_
np.mean(np.mod(LR.predict(x)-y))

from sklearn import metrics
print(metrics.mean_absolute_error(LR.predict(x),y))