#!/usr/bin/env python
from __future__ import print_function
from itertools import count

import torch
import pandas as pd
import os

myname = "srijit sen"
lib_path = "D:/MDS related Documents/Deep Learning/Assignment 1/"
os.chdir(lib_path)

def make_features():
   training_data=pd.read_csv('qn2_data.csv',names=('Fert','Insect','Corn'))
   y=training_data['Corn'].values
   x=training_data.drop('Corn', axis=1).values
   X = torch.Tensor(x)
   Y = torch.Tensor(y)
   new_shape = (len(Y), 1)
   Y = Y.view(new_shape)
   return X,Y

def poly_desc(W, b):
    """Creates a string description of a polynomial."""
    result = 'y = '
    for i, w in enumerate(W):
        result += '{:+.2f} x^{} '.format(w, 1)
    result += '{:+.2f}'.format(b[0])
    return result


# Define model
X,Y=make_features()
batch_size=5
fc = torch.nn.Linear(X.size(1), 1)
test_set = torch.Tensor([[6,4],[10,5],[34,26]])

 ##model parameters
optimizer = torch.optim.SGD(fc.parameters(), lr=0.01) #torch optim sgd optimizer

for batch_idx in count(1): #infinite loop
    
    ### Implementing stochastic sampling
    permutation = torch.randperm(X.size()[0])
    
    # Reset gradients to zero for each mini batch before starting calculation for gradient
    for i in range(0,X.size()[0], batch_size):
        optimizer.zero_grad()
        
        indices = permutation[i:i+batch_size]
        batch_x, batch_y = X[indices], Y[indices]
        
        # Forward pass,calculating error- Function that uses a squared term if the absolute element-wise error falls below beta and an L1 term otherwise.
        output = torch.nn.functional.smooth_l1_loss(fc(batch_x), batch_y) 
        loss = output.item()

        # Backward pass
        output.backward()

        # Apply gradients
        optimizer.step()
    
    # Stop criterion
    if batch_idx>50000:
        break

### Prediction on tst ###
fc(test_set)

print('Loss: {:.6f} after {} batches'.format(loss, batch_idx))
print('==> Learned function:\t' + poly_desc(fc.weight.view(-1), fc.bias))
